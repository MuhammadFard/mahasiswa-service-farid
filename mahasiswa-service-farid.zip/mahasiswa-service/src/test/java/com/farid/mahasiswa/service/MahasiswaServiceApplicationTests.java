package com.farid.mahasiswa.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MahasiswaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
